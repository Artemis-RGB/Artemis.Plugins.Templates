﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for CustomView.xaml
    /// </summary>
    public partial class CustomView : UserControl
    {
        public CustomView()
        {
            InitializeComponent();
        }
    }
}